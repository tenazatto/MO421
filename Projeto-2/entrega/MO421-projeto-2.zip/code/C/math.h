extern int gcd(int x, int y);
extern int coprimality(int x, int y);
extern int mod_inverse(int a, int m);
