Configurações mínimas (modo automático):

Java 8 instalado
1,5 GB RAM para Linux
2 GB RAM para Windows

Configurações recomendadas (modo automático):

Java 8 instalado
4 GB RAM

Executar com:

java -jar (JAR a ser executado).jar (caminho do texto 1) (caminho do texto 2)

Exemplo:

java -jar OTP-Break_AUTOMATIC.jar ./challenge1.txt ./challenge2.txt

OU

java -jar O
TP-Break_AUTOMATIC.jar "./challenge1.txt" "./challenge2.txt"

Certifique-se de que a pasta "resources" esteja na mesma pasta dos JARs, caso contrário a decifração não funcionará.
