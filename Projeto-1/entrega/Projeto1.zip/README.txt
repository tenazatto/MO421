UNIVERSIDADE ESTADUAL DE CAMPINAS
Instituto de Computação – IC
MO421 – Introdução a Criptografia
Prof. Dr. Diego de Freitas Aranha

Projeto 1

Aluno: Thales Eduardo Nazatto
RA: 074388

Neste pacote estão incluídos:

- O relatório contendo detalhes do desenvolvimento e resultados, em formato PDF.
- A pasta "code", contendo os códigos feitos durante o desenvolvimento do projeto (C / Java).
- A pasta "software", contendo os programas (JARs) finais de cada fase do desenvolvimento e dicionários para execução do programa.

Cada pasta possuí um arquivo README.txt contendo as instruções para compilação / execução.

Bom divertimento! =D
