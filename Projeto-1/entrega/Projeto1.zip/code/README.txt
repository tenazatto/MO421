ATENÇÃO: Para o projeto final, compilar apenas a parte Java. A parte C é meramente ilustrativa e não representa o projeto final. Serve apenas para dar veracidade ao apresentado no projeto

Instruções de compilação:

Java:

Entrar na pasta Java e executar o shell script "compileJavaMakeJar.sh". Certificar de que ele está com as permissões necessárias, e efetuar o comando chmod em caso contrário. O shell compilará as classes e fará o JAR.
Certificar de estar com o JDK 8 instalado em sua máquina.
Logo após a compilação, executar o JAR na pasta "software" localizada no projeto.

A compilação Java já está configurada para o modo automático.

C:

Entrar na pasta C via terminal e digitar o comando "make otp-break mostlyclean".

