int mode = 1;
