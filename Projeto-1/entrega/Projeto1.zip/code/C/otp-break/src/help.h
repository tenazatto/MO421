void help_all();
void help_key();
void help_cipher();
void help_intro();