package model;

/**
 * Created by thales on 08/04/17.
 */
public class Key {
    private byte[] key;

    public byte[] getKey() {
        return key;
    }

    public void setKey(byte[] key) {
        this.key = key;
    }
}
