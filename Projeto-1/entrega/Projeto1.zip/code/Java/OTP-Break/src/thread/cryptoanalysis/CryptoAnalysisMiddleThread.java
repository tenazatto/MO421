package thread.cryptoanalysis;

/**
 * Created by thales on 09/04/17.
 */
public class CryptoAnalysisMiddleThread implements Runnable {

    @Override
    public void run() {

    }
}
